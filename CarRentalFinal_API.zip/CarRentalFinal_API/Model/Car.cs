﻿namespace CarRentalFinal_API.Model
{
    public class Car
    {

    }
}
